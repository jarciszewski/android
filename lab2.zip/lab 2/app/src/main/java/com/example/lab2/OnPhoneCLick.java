package com.example.lab2;

public interface OnPhoneCLick {
    void onPhoneClick(Phone phone);
}
