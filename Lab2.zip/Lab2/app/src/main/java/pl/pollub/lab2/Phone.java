package pl.pollub.lab2;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "smartphones")
public class Phone {
    public class Element {
        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "telephone_id")
        private long mId;

        @NonNull
        @ColumnInfo(name = "OEM")
        private String mOEM;

        @NonNull
        @ColumnInfo(name = "model")
        private String mModel;

        @NonNull
        @ColumnInfo(name = "androidVersion")
        private String mVersion;

        @NonNull
        @ColumnInfo(name = "Website")
        private String mSite;

        public Phone(@NonNull String mOEM, @NonNull String mModel, @NonNull String mVersion, @NonNull String mSite){
            this.mOEM = mOEM;
            this.mModel = mModel;
            this.mVersion = mVersion;
            this.mSite = mSite;
        }

        public long getmId() {
            return mId;
        }

        @NonNull
        public String getmModel() {
            return mModel;
        }

        @NonNull
        public String getmOEM() {
            return mOEM;
        }

        @NonNull
        public String getmSite() {
            return mSite;
        }

        @NonNull
        public String getmVersion() {
            return mVersion;
        }

        public void setmId(long mId) {
            this.mId = mId;
        }

        public void setmModel(@NonNull String mModel) {
            this.mModel = mModel;
        }

        public void setmOEM(@NonNull String mOEM) {
            this.mOEM = mOEM;
        }

        public void setmSite(@NonNull String mSite) {
            this.mSite = mSite;
        }

        public void setmVersion(@NonNull String mVersion) {
            this.mVersion = mVersion;
        }
    }
}
