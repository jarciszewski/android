package pl.pollub.lab2;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class PhoneViewModel {
    private PhoneDao mPhoneDao;
    private LiveData<List<Phone>> mAllPhones;
    PhoneViewModel(Application application) {
        PhoneRoomDatabase wordRoomDatabase = PhoneRoomDatabase.getDatabase(application);
        mPhoneDao = wordRoomDatabase.phoneDao();
        mAllPhones = mPhoneDao.getAlphabetizedWords();
    }
    LiveData<List<Phone>> getAllWords() { return mAllPhones; }

    void insert(Phone phone) {
        PhoneRoomDatabase.databaseWriteExecutor.execute(() -> {
            mPhoneDao.insert(phone);
        });
    }
    void deleteAll() {
        PhoneRoomDatabase.databaseWriteExecutor.execute(() -> {
            mPhoneDao.deleteAll();
        });
    }
    void deleteWord(Phone phone)
    { PhoneRoomDatabase.databaseWriteExecutor.execute(() -> {
        mPhoneDao.deleteWord(phone);
    });
    }
}
